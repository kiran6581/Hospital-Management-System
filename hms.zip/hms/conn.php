<?php
$con=mysqli_connect("localhost","root","","myhmsdb");
if(!$con){
    echo mysqlI_error($con);
}

?>