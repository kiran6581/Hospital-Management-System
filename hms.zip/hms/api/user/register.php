<?php
error_reporting(0);
session_start();
include("../../conn.php");

$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$gender=$_POST['gender'];
$number=$_POST['number'];
$password=$_POST['password'];
$cpassword=$_POST['cpassword'];

if($fname==""){
    echo"First Name Required";
    exit(0);
}
if($lname==""){
    echo"Last Name Required";
    exit(0);
}
if($email==""){
    echo"Email Required";
    exit(0);
}
if($gender==""){
    echo"Gender Required";
    exit(0);
}
if($number==""){
    echo"Number Required";
    exit(0);
}
if($password==""){
    echo"Passwrod Required";
    exit(0);
}
if($cpassword==""){
    echo"Confirm Passwrod Required";
    exit(0);
}


$query="insert into users(fname,lname,gender,email,contact,password,cpassword) values ('$fname','$lname','$gender','$email','$number','$password','$cpassword');";
    $result=mysqli_query($con,$query);
    if($result){
        $_SESSION['username'] = $_POST['fname']." ".$_POST['lname'];
        $_SESSION['fname'] = $_POST['fname'];
        $_SESSION['lname'] = $_POST['lname'];
        $_SESSION['gender'] = $_POST['gender'];
        $_SESSION['contact'] = $_POST['number'];
        $_SESSION['email'] = $_POST['email'];
        echo "success";
        $query1 = "select * from users;";
        $result1 = mysqli_query($con,$query1);
        if($result1){
            $row = mysqli_fetch_array($result1);
            $_SESSION['pid'] = $row['pid'];
        }
    }else{
        echo"Something Went Wrong";
    }

    