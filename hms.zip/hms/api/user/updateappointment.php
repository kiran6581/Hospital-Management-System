<?php
error_reporting(0);
session_start();
include("../../conn.php");
$pid=$_SESSION['pid'];
if(!$pid){
  echo "user not login";
  die;
}

$query=mysqli_query($con,"update appointmenttb set userStatus='0' where ID = '".$_POST['id']."' AND pid='".$_SESSION['pid']."'");
if($query){
      echo "success";
}else{
    echo"Something Went Wrong";
}
