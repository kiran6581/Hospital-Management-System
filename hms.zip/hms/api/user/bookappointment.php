<?php
error_reporting(0);
session_start();
include("../../conn.php");
$pid=$_SESSION['pid'];
if(!$pid){
  echo "user not login";
  die;
}
$username = $_SESSION['username'];
$email = $_SESSION['email'];
$fname = $_SESSION['fname'];
$lname = $_SESSION['lname'];
$gender = $_SESSION['gender'];
$contact = $_SESSION['contact'];
$doctor=$_POST['doctor'];
$spec=$_POST['spec'];
$docFees=$_POST['docFees'];
$appdate=$_POST['appdate'];
$apptime=$_POST['apptime'];
$cur_date = date("Y-m-d");
date_default_timezone_set('Asia/Kolkata');
$cur_time = date("H:i:s");
$apptime1 = strtotime($apptime);
$appdate1 = strtotime($appdate);
if($doctor==""){
    echo"Doctor Name Required";
    exit(0);
}
if($spec==""){
    echo"Specificattion Required";
    exit(0);
}
if($docFees==""){
    echo"Doctor Fees Required";
    exit(0);
}
if($appdate==""){
    echo"Appointment Date Required";
    exit(0);
}
if($apptime==""){
    echo"Appointment Time Required";
    exit(0);
}
if(date("Y-m-d",$appdate1)>=$cur_date){
    if((date("Y-m-d",$appdate1)==$cur_date and date("H:i:s",$apptime1)>$cur_time) or date("Y-m-d",$appdate1)>$cur_date) {
      $check_query = mysqli_query($con,"select apptime from appointmenttb where doctor='$doctor' and appdate='$appdate' and apptime='$apptime'");

        if(mysqli_num_rows($check_query)==0){
          $query=mysqli_query($con,"insert into appointmenttb(pid,fname,lname,gender,email,contact,doctor,docFees,appdate,apptime,userStatus,doctorStatus) values($pid,'$fname','$lname','$gender','$email','$contact','$doctor','$docFees','$appdate','$apptime','1','1')");

          if($query)
          {
            echo "success";
          }
          else{
            echo "Unable to process your request. Please try again!";
          }
      }
      else{
        echo "We are sorry to inform that the doctor is not available in this time or date. Please choose different time or date!";
      }
    }
    else{
      echo "Select a time or date in the future!";
    }
}else{
      echo "Select a time or date in the future!";
}
