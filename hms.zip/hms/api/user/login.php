<?php
error_reporting(0);
session_start();
include("../../conn.php");

$email=$_POST['email'];
$password=$_POST['password'];

if($email==""){
    echo"Email Required";
    exit(0);
}
if($password==""){
    echo"Passwrod Required";
    exit(0);
}


$query="select * from users where email='$email' and password='$password';";
$result=mysqli_query($con,$query);
if(mysqli_num_rows($result)==1){
	while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
      $_SESSION['pid'] = $row['pid'];
      $_SESSION['username'] = $row['fname']." ".$row['lname'];
      $_SESSION['fname'] = $row['fname'];
      $_SESSION['lname'] = $row['lname'];
      $_SESSION['gender'] = $row['gender'];
      $_SESSION['contact'] = $row['contact'];
      $_SESSION['email'] = $row['email'];
      echo"success";
      exit(0);
    }
}else{
    echo"Wrong Details";
    exit(0);
}