<?php
error_reporting(0);
session_start();
include("../../conn.php");
$dname=$_SESSION['dname'];
if(!$dname){
  echo "Doctor not login";
  die;
}
$query=mysqli_query($con,"update appointmenttb set doctorStatus='0' where ID = '".$_POST['id']."'");
if($query){
      echo "success";
}else{
    echo"Something Went Wrong";
}
