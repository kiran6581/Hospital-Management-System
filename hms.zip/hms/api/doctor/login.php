<?php
error_reporting(0);
session_start();
include("../../conn.php");

$username=$_POST['username'];
$password=$_POST['password'];

if($username==""){
    echo"Username Required";
    exit(0);
}
if($password==""){
    echo"Passwrod Required";
    exit(0);
}

$query="select * from doctors where username='$username' and password='$password';";
$result=mysqli_query($con,$query);
if(mysqli_num_rows($result)==1){
    while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		$_SESSION['dname']=$row['username'];  
    }
		echo"success";
        exit(0);
}else{
    echo"Wrong Details";
    exit(0);
}