<?php
error_reporting(0);
session_start();
include("../../conn.php");
$dname=$_SESSION['dname'];
if(!$dname){
  echo "Doctor not login";
  die;
}

$fname=$_POST['fname'];
$lname=$_POST['lname'];
$appdate=$_POST['appdate'];
$apptime=$_POST['apptime'];
$pid=$_POST['pid'];
$ID=$_POST['ID'];
$disease=$_POST['disease'];
$allergy=$_POST['allergy'];
$prescription=$_POST['prescription'];
$query=mysqli_query($con,"insert into prestb(doctor,pid,ID,fname,lname,appdate,apptime,disease,allergy,prescription) values ('$dname','$pid','$ID','$fname','$lname','$appdate','$apptime','$disease','$allergy','$prescription')");
if($query){
    echo "success";
}else{
    echo"Something Went Wrong";
}
